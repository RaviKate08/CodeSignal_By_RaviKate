boolean isDigit(char symbol) 
{
    if(Character.isDigit(symbol))
    {
        return true;
    }
    else
    {
        return false;
    }

}
