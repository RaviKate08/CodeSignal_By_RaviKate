int shapeArea(int n)
 {
if(n<0)
{
    return 0;
}
else
{
    return (n*n)+((n-1)*(n-1));
}
}
