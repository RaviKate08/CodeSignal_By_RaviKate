int seatsInTheater(int nCols, int nRows, int col, int row)
 {
     int a=nCols-col+1;
     int b=nRows-row;
     return a*b;

}
