int largestNumber(int n)
 {
     int x=(int)Math.pow(10,n);
     return x-1;

}
