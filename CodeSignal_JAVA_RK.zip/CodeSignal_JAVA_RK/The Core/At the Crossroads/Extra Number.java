int extraNumber(int a, int b, int c)
 {
     if(a==b)
     {
         return c;
     }
     if(b==c)
     {
         return a;
     }
     return b;

}
